<?php

namespace App\Http\Controllers;

use App\Models\SuretyBondDraftScore;
use Illuminate\Http\Request;

class SuretyBondDraftScoreController
{
    public function index()
    {
    }

    public function create()
    {
    }

    public function store(Request $request)
    {
    }

    public function show(SuretyBondDraftScore $suretyBondDraftScore)
    {
    }

    public function edit(SuretyBondDraftScore $suretyBondDraftScore)
    {
    }

    public function update(Request $request, SuretyBondDraftScore $suretyBondDraftScore)
    {
    }

    public function destroy(SuretyBondDraftScore $suretyBondDraftScore)
    {
    }
}
