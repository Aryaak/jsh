<?php

namespace Database\Factories;

use App\Models\SuretyBondDraft;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends Factory<SuretyBondDraft>
 */
class SuretyBondDraftFactory extends Factory
{
    protected $model = SuretyBondDraft::class;

    public function definition()
    {
        return [
            //
        ];
    }
}
