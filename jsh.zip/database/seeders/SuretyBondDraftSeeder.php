<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SuretyBondDraftSeeder extends Seeder
{
    public function run()
    {
        //
    }
}
