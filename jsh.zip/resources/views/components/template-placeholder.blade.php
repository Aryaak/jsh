<span class="mb-3 d-inline-block"><code class="border rounded border-secondary bg-label-secondary p-2 text-dark">{!! $slot !!}</code></span>
