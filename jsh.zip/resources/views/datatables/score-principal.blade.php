<x-badge :face='$model->scoreColor' rounded>{{ Str::replace('.', ',', $model->score) }}</x-badge>
